import numpy as np
import cv2, example
import matplotlib.pyplot as plt


image_rgb = cv2.imread('test.png', -1)
image_gray = cv2.imread('test.png', 0)

var1 = example.RGB2Gray(image_rgb)
var1 = (var1*1.2).clip(0,255).astype("uint8")
plt.figure('rgb-gray'); plt.imshow(var1, cmap="gray")

var2 = example.GrayCanny(image_gray)
plt.figure('canny'); plt.imshow(var2)

var3 = example.Pyramid4(image_rgb)
plt.figure('pyramid_demo')
for i, image in enumerate(var3[:4], 1):
    plt.subplot(2, 2, i); plt.axis('off')
    plt.imshow(image[:,:,::-1])

print(var1.shape, var3[4].shape)
plt.show()