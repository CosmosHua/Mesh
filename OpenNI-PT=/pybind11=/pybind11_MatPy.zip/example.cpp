#include <vector>
#include <iostream>
#include <pybind11/stl.h>
#include "MatPy.h"

namespace py = pybind11;


py::array_t<unsigned char> RGB2Gray(py::array_t<unsigned char>& input)
{
    cv::Mat src = numpy2Mat(input), dst;
    cv::cvtColor(src, dst, cv::COLOR_RGB2GRAY);
    return Mat2numpy(dst);
}//end RGB2Gray


py::array_t<unsigned char> GrayCanny(py::array_t<unsigned char>& input)
{
    cv::Mat src = numpy2Mat(input), dst;
    cv::Canny(src, dst, 30, 60);
	cv::cvtColor(dst, dst, cv::COLOR_GRAY2RGB);
    return Mat2numpy(dst);
}//end GrayCanny


//@return Python list
py::list Pyramid4(py::array_t<unsigned char>& input)
{
    std::vector<cv::Mat> dst;
    cv::Mat src = numpy2Mat(input);
    cv::buildPyramid(src, dst, 4);

    py::list out;
    for (unsigned int i = 0; i < dst.size(); i++)
        out.append<py::array_t<unsigned char>>(Mat2numpy(dst.at(i)));
    return out;
}//end Pyramid4


PYBIND11_MODULE(example, m)
{
    m.doc() = "Simple OpenCV Demo";
    m.def("RGB2Gray", &RGB2Gray);
    m.def("GrayCanny", &GrayCanny);
    m.def("Pyramid4", &Pyramid4);
}//end PYBIND11_MODULE