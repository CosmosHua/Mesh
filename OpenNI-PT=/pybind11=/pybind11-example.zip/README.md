For Linux:

mkdir build; cd build
cmake ..; make
python
	import test
	...