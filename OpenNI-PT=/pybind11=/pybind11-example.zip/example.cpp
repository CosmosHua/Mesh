#include <pybind11/pybind11.h>

namespace py = pybind11;


int add(int i=1, int j=2)
{	return i+j;	}


class Pet
{
private:
	std::string name;
public:
	int num = 0;
	Pet(const std::string &name):name(name) { }
	void setName(const std::string &name_) { name = name_; }
	const std::string &getName() const { return name; }
};


PYBIND11_MODULE(test, m)
{
	m.attr("num") = 42;
	m.attr("what") = py::cast("World");
	m.def("add", &add, "ADD", py::arg("i")=1, py::arg("j")=2);
	py::class_<Pet> pet(m, "Pet", py::dynamic_attr());
	pet.def(py::init<const std::string &>())
		.def_readwrite("num", &Pet::num) //for public
		.def_property("name", &Pet::getName, &Pet::setName) //for private
		.def("setName", &Pet::setName)
		.def("getName", &Pet::getName);
}
