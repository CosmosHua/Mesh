#include <net.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <algorithm>
#include <functional>
#include <opencv.hpp>

#include "ldm106_id.h"

using namespace cv;
using namespace std;


////////////////////////////////////////////////////////////////////////////////
static float HeadPoseArray[] =
{
    0.139791,27.4028,7.02636,
    -2.48207,9.59384,6.03758,
    1.27402,10.4795,6.20801,
    1.17406,29.1886,1.67768,
    0.306761,-103.832,5.66238,
    4.78663,17.8726,-15.3623,
    -5.20016,9.29488,-11.2495,
    -25.1704,10.8649,-29.4877,
    -5.62572,9.0871,-12.0982,
    -5.19707,-8.25251,13.3965,
    -23.6643,-13.1348,29.4322,
    67.239,0.666896,1.84304,
    -2.83223,4.56333,-15.885,
    -4.74948,-3.79454,12.7986,
    -16.1,1.47175,4.03941
};
static cv::Mat HeadPoseMat = cv::Mat(15, 3, CV_32FC1, HeadPoseArray);


////////////////////////////////////////////////////////////////////////////////
void HeadPose(const cv::Mat &KP, cv::Vec3d &eav)
{
    if (KP.empty()) return;
    float sumx = 0.0f, sumy = 0.0f;
    float miny = 10000000000.0f, maxy = 0.0f;
    static std::vector<int> HeadPosePointId = { 36,39,42,45,30,48,54 };
    static int N = (int)HeadPosePointId.size(); //OR:{7,16,17,8,9,10,11};
    for (int i = 0; i < N; i++)
    {
        int id = HeadPosePointId[i];
        sumx += KP.at<float>(id);
        float y = KP.at<float>(id + KP.cols/2);
        sumy += y;
        if (miny > y) miny = y;
        if (maxy < y) maxy = y;
    }//end for

    sumx /= N; sumy /= N;
    float dist = maxy - miny;
    static cv::Mat pred(1, 2*N + 1, CV_32FC1);
    for (int i = 0; i < N; i++)
    {
        int id = HeadPosePointId[i];
        pred.at<float>(i) = (KP.at<float>(id) - sumx) / dist;
        pred.at<float>(i + N) = (KP.at<float>(id + KP.cols/2) - sumy) / dist;
    }//end for
    pred.at<float>(2*N) = 1.0f;

    pred = pred*HeadPoseMat;
    eav[0] = pred.at<float>(0);
    eav[1] = pred.at<float>(1);
    eav[2] = pred.at<float>(2);
}//end HeadPose


////////////////////////////////////////////////////////////////////////////////
std::vector<float> landmark_detect(cv::Mat &face, const ncnn::Net &net)
{
    cv::Mat F; //F should be square
    cv::resize(face, F, Size(224, 224));
    //cv::cvtColor(face, F, COLOR_RGB2BGR);
    //F.convertTo(F, CV_32FC3);

    ncnn::Mat in, out;
    clock_t tt = clock(); const int hw = 112;
    static float mean3[3] = { 127.5, 127.5, 127.5 };
    static float norm3[3] = { 0.0078125, 0.0078125, 0.0078125 };
    ncnn::Extractor ex = net.create_extractor(); //ex.set_light_mode(true);
    in = ncnn::Mat::from_pixels_resize(F.data, ncnn::Mat::PIXEL_RGB, F.rows, F.cols, hw, hw);
    in.substract_mean_normalize(mean3, norm3);

    ex.input(ldm106_param_id::LAYER_data, in);
    ex.extract(ldm106_param_id::BLOB_bn6_3, out);
    float ttm = 1000.0 * (clock()-tt) / CLOCKS_PER_SEC;
    printf("landmark time: %.1f ms\n", ttm);

    std::vector<float> feat;
    const float* prob = (const float*)out.data;
    for (int k = 0; k < out.w; k++) feat.push_back(prob[k]);
    return feat;
}//end landmark_detect


////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
    //Mat face = cv::imread(argv[1], -1);
    cv::Mat face = cv::imread("1.jpg", -1);
    if (face.rows>750 ||face.cols>1000)
    cv::resize(face, face, Size(0,0), 0.5, 0.5);

    //start face landmark detection
    ncnn::Net squeezenet;
    squeezenet.load_param_bin("ldm106.param.bin");
    squeezenet.load_model("ldm106.bin");
    std::vector<float> feat = landmark_detect(face, squeezenet);

    std::vector<int> KP(136);
    for (int i=0, j = 0; j < 106; j++)
    {
        cv::Point x = Point(int(feat[2*j] * face.cols), int(feat[2*j+1] * face.rows));
        cv::circle(face, x, 1, Scalar(0, 0, 255), 2); //draw landmarks
        if ((j <= 32 && j % 2 == 0) || (j >= 33 && j <= 63) || (j >= 84 && j <= 103))
        {
            KP[i] = x.x; KP[i + 68] = x.y; i++;
        }//end if
    }//end for
    cv::Mat KP_Mat = cv::Mat(KP, true).t();
    cv::Vec3d eav; HeadPose(KP_Mat, eav);
    cout << "[x,z,y]-rotate degree: "<< eav << endl;

    cv::imshow("result", face); cv::waitKey(0);
    cv::destroyAllWindows(); return 0; 
}//end main
