1.First, install its driver <SensorDriver.exe>.

2.As <Cam.cp36_win64.pyd> is built by:
    CMake, VS2015_x64, OpenCV3.3.0, Python3.6, pybind11
So, to use it, require:
    Python3.6 environment (Python3.7 is not OK)
    copy <x64/vc14/bin/opencv_world330.dll> here (OR: add in PATH)
