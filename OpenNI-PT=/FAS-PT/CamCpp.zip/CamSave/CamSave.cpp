#include "CamMS.h"
#include <iostream>
//#include <opencv.hpp>

//using namespace cv;
//using namespace std;


void main(int argc, char** argv)
{
    Cam ACam; int ret;
    ret = ACam.InitStream(openni::SENSOR_COLOR);
    if (ret != 0) throw std::runtime_error("Error: SENSOR_COLOR!");
    ret = ACam.InitStream(openni::SENSOR_DEPTH);
    if (ret != 0) throw std::runtime_error("Error: SENSOR_DEPTH!");

    cv::VideoWriter VID;
    std::vector<cv::Mat> Img;
    cv::Mat Color, Depth, IR, IC, im;
    int vid = 0, f2p = 0, sup = 0, tid = 0;
    for (int i = 0; ; i++)
    {
        IR = ACam.GetFrame(openni::SENSOR_IR);
        Color = ACam.GetFrame(openni::SENSOR_COLOR);
        Depth = ACam.GetFrame(openni::SENSOR_DEPTH);
        //Depth = ACam.GetFrame(openni::SENSOR_DEPTH, IRFrame);

        if (!Depth.empty()) Img.push_back(Depth);
        if (!Color.empty()) Img.push_back(Color);
        if (!IR.empty())    Img.push_back(IR);
        if (Img.size()>0)   cv::hconcat(Img, im);
        if (sup) Superpose(im, Img, sup);
        Img.clear(); //erase all

        if (!im.empty()) cv::imshow("Cam", im); //show
        if (vid) SaveVideo(im, VID); else VID.release();
        if (f2p) SaveImage(im, tid, i, f2p); //save images

        int key = cv::waitKey(10);
        switch (key)
        {
        case 'c': //switch SENSOR_COLOR
            if (ACam.isValid(openni::SENSOR_COLOR))
                ACam.CloseStream(openni::SENSOR_COLOR);
            else ACam.InitStream(openni::SENSOR_COLOR);
            break;
        case 'd': //switch SENSOR_DEPTH
            if (ACam.isValid(openni::SENSOR_DEPTH))
                ACam.CloseStream(openni::SENSOR_DEPTH);
            else ACam.InitStream(openni::SENSOR_DEPTH);
            break;
        case 'i': //switch SENSOR_IR
            if (ACam.isValid(openni::SENSOR_IR))
                ACam.CloseStream(openni::SENSOR_IR);
            else ACam.InitStream(openni::SENSOR_IR);
            break;
        case 's': //superpose images
            if (sup < 3) sup++; else sup = 0;
            break; //0=none, 1=superpose, 2/3=Alpha
        case 32: vid = !vid; break; //Space->save to video
        case 13: f2p = (!f2p)*time(0); break; //Enter->save images
        case 27: return; //ESC->exit
        }//end switch
    }//end for

    //openni::CoordinateConverter coorvert;
    //coorvert.convertDepthToWorld();
}//end main

