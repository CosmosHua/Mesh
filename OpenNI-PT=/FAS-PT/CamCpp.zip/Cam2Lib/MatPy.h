#ifndef __MAT_WRAP_H__

#include <opencv2/opencv.hpp>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

namespace py = pybind11;

cv::Mat numpy2Mat(py::array_t<unsigned char>& array);
py::array_t<unsigned char> Mat2numpy(cv::Mat & input);

#endif//end __MAT_WRAP_H__