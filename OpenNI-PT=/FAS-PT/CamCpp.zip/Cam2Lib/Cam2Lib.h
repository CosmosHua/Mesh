#pragma once


#ifndef __CAM_RGBD_H__
#define __CAM_RGBD_H__


#include "MatPy.h"
#include <OpenNI.h>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

namespace py = pybind11;


class Cam
{
private:
    void* m_device;
    void* m_stream_color;
    void* m_stream_depth;
    void* m_stream_ir;

    int OpenDevice();
    int CloseDeivce();
    void Destroy(void* &m_stream);

public:
    Cam();
    ~Cam();
    int TimeOut = 150; //ms
    int InitStream(const int CamType);
    int CloseStream(const int CamType);
    bool isValid(const int CamType)const;
    py::array_t<unsigned char> GetD()const;
    py::array_t<unsigned char> GetIR()const;
    py::array_t<unsigned char> GetRGB()const;
    py::array_t<unsigned char> GetRGBD()const;
    py::array_t<unsigned char> Frame(const int CamType)const;
    //function pointer, which transforms openni::VideoFrameRef to cv::Mat
    cv::Mat GetFrame(const int CamType, cv::Mat(*pf)(const openni::VideoFrameRef&)=NULL)const;
};//end Cam


cv::Mat IRFrame(const openni::VideoFrameRef& Frame);
cv::Mat RGBFrame(const openni::VideoFrameRef& Frame);
cv::Mat DepthFrame(const openni::VideoFrameRef& Frame);


#endif //__CAM_RGBD_H__
