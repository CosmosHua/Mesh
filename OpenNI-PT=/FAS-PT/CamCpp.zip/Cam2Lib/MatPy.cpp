#include "MatPy.h"


cv::Mat numpy2Mat(py::array_t<unsigned char>& array)
{
    int d = (int)array.ndim();
    int type = (d==2)*CV_8UC1 + (d==3)*CV_8UC3;
    if(d<2||d>3) throw std::runtime_error("Wrong dims!");

    py::buffer_info buf = array.request();
    return cv::Mat(buf.shape[0], buf.shape[1], type, (unsigned char*)buf.ptr);
}//end numpy2Mat


py::array_t<unsigned char> Mat2numpy(cv::Mat& mat)
{
    int c = mat.channels();
    if(c<2) return py::array_t<unsigned char>({mat.rows, mat.cols}, mat.data);
    else return py::array_t<unsigned char>({mat.rows, mat.cols, c}, mat.data);
}//end Mat2numpy


PYBIND11_MODULE(MatPy, m)
{
    m.doc() = "OpenCV Mat<->numpy.ndarray";
    m.def("numpy2Mat", &numpy2Mat);
    m.def("Mat2numpy", &Mat2numpy);
}//end PYBIND11_MODULE