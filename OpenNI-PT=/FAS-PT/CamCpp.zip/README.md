################################################################################
For CamSave(Windows10, VS2015):
1. Open VS2015, create an new empty project.
2. add Source Files: CamMS.cpp, CamTest.cpp;
   add Header Files: CamMS.h
3. Select "Release x64"; Configure OpenCV+OpenNI(see below).
4. Build; Copy <Orbbec_SDK/x64-Release/*> into <x64/Release>;
   then press CTRL+F5 to run.
    

# For pybind11: pip3 install pybind11
################################################################################
For Cam2Lib(Windows10, VS2015):
1. Copy <pybind11> to <This_Dir>;
2. cmake-gui: source=<This_Dir>, build=<build>; press Configure;
   select “USE_PYTHON_INCLUDE_DIR”; press Generate.
3. Open "Cam.sln" using VS2015; Select "Release x64";
   Configure OpenCV+OpenNI+Python(see below);
4. Build; obtain: <build>/Release/Cam.cp36-win_amd64.pyd.
5. Copy <Orbbec_SDK/x64-Release/*> to the folder above;
   input "import Cam" in python for test.


# Install/Extract: OpenCV3.3, Orbbec_SDK, Python3.6.
Configure: OpenCV+OpenNI+Python+NCNN for project(Release,x64)
################################################################################
VC++ Directories->Inlude Directories:
    D:/OpenCV/include
    D:/OpenCV/include/opencv
    D:/OpenCV/include/opencv2
    D:/Orbbec_SDK/Include
    D:/Python36/include
    <ncnn-root-dir>/install/include/ncnn

VC++ Directories->Library Directories:
    D:/OpenCV/x64/vc14/lib
    D:/Orbbec_SDK/x64-Release
    D:/Python36/libs
    <ncnn-root-dir>install/lib

Linker->Input->Additional Dependencies:
    opencv_world330.lib
    OpenNI2.lib
    python36.lib
    ncnn.lib


################################################################################
