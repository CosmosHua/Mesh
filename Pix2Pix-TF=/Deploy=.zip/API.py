# coding:utf-8
#!/usr/bin/python3
from model_ import *


################################################################################
class P2P(object):
    def __init__(self, model="./checkpoint", sess=None):
        assert os.path.isdir(model); self.model_dir = model
        config = tf.ConfigProto(device_count={"GPU":1}, allow_soft_placement=True)
        config.gpu_options.allow_growth = True # dynamicly apply gpu_memory
        self.sess = sess if type(sess)==tf.Session else tf.Session(config=config)


    def infer(self, images):
        p2p = pix2pix(self.sess, phase="test", checkpoint_dir=self.model_dir)
        self.test_dir = images; return p2p.test(self)


#os.environ["CUDA_VISIBLE_DEVICES"]="" # assign/disable GPUs
################################################################################
if __name__ == '__main__':
    from sys import argv; api = P2P()
    for im in argv[1:]: api.infer(im)

