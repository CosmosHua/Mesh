# coding:utf-8
#!/usr/bin/python3

import cv2
import numpy as np
import tensorflow as tf
from tensorflow.python.framework import ops


TType = tf.float32; # TType = tf.float16
################################################################################
def lrelu(x, leak=0.2, name="lrelu"):   return tf.maximum(x, leak*x)
def Lrelu(x, leak=0.1, name="Lrelu"):   return tf.maximum(x, leak*x)


# batch normalization: => instance for batch=1
# deals with poor initialization, enhances gradient flow
def batch_norm(x, isTrain=True, name="batch_norm"): # instance_norm for batch=1
    return tf.contrib.layers.batch_norm(x, decay=0.9, epsilon=1E-5, scale=True, is_training=isTrain, 
                                        updates_collections=None, scope=name) # early version


def binary_cross_entropy(preds, targets, name=None):
    """
    Computes binary cross entropy given `preds`.
    For brevity, let `x = `, `z = targets`.  The logistic loss is
        loss(x, z) = - sum_i (x[i] * log(z[i]) + (1 - x[i]) * log(1 - z[i]))
    Args:
        preds: A `Tensor` of type `float32` or `float64`.
        targets: A `Tensor` of the same type and shape as `preds`.
    """
    eps = 1e-12
    with ops.op_scope([preds, targets], name, "bce_loss") as name:
        preds = ops.convert_to_tensor(preds, name="preds")
        targets = ops.convert_to_tensor(targets, name="targets")
        return tf.reduce_mean(-(targets * tf.log(preds+eps) + (1-targets) * tf.log(1-preds+eps)))


def conv_cond_concat(x, y):
    """Concatenate conditioning vector on feature map axis."""
    x_shapes = x.get_shape(); y_shapes = y.get_shape()
    return tf.concat([x, y*tf.ones([x_shapes[0],x_shapes[1],x_shapes[2],y_shapes[3]])], 3)


def conv2d(input, output_dim, k_h=4, k_w=4, d_h=2, d_w=2, stddev=0.02, name="conv2d"):
    with tf.variable_scope(name):
        shape = [k_h, k_w, input.get_shape()[-1], output_dim]
        w = tf.get_variable('w', shape, TType, initializer=tf.truncated_normal_initializer(stddev=stddev))
        conv = tf.nn.conv2d(input, w, strides=[1, d_h, d_w, 1], padding='SAME')
        biases = tf.get_variable('biases', [output_dim], TType, initializer=tf.constant_initializer(0.0))
        conv = tf.reshape(tf.nn.bias_add(conv, biases), conv.get_shape())
        return conv


def deconv2d(input, output_shape, k_h=4, k_w=4, d_h=2, d_w=2, stddev=0.02, name="deconv2d", with_w=True):
    with tf.variable_scope(name):
        # filter : [height, width, output_channels, in_channels]
        shape = [k_h, k_w, output_shape[-1], input.get_shape()[-1]]
        w = tf.get_variable('w', shape, TType, initializer=tf.random_normal_initializer(stddev=stddev))
        try:
            deconv = tf.nn.conv2d_transpose(input, w, output_shape=output_shape, strides=[1, d_h, d_w, 1])
        except AttributeError: # Support for verisons of TensorFlow before 0.7.0
            deconv = tf.nn.deconv2d(input, w, output_shape=output_shape, strides=[1, d_h, d_w, 1])
        biases = tf.get_variable('biases', [output_shape[-1]], TType, initializer=tf.constant_initializer(0.0))
        deconv = tf.reshape(tf.nn.bias_add(deconv, biases), deconv.get_shape())
        return (deconv, w, biases) if with_w else deconv


def linear(input, output, name=None, stddev=0.02, bias_start=0.0, with_w=False):
    shape = input.get_shape().as_list()
    with tf.variable_scope(name or "Linear"):
        matrix = tf.get_variable("Matrix", [shape[1], output], TType, tf.random_normal_initializer(stddev=stddev))
        bias = tf.get_variable("bias", [output], TType, initializer=tf.constant_initializer(bias_start))
        if with_w:  return tf.matmul(input, matrix) + bias, matrix, bias
        else:       return tf.matmul(input, matrix) + bias


import os, cv2
from glob import glob

rsz = lambda im,wh: cv2.resize(im, tuple(wh))
globs = lambda DIR,x: sorted(glob(os.path.join(DIR,x)))
################################################################################
def load_image(src, size=(256,256), isTrain=True, mod="_"):
    A = src if type(src)!=str else cv2.imread(src); B = A
    A = rsz(A, size)/127.5-1 # resize->center normalize
    B = rsz(B, size)/127.5-1 # resize->center normalize
    BA = np.concatenate((B,A), axis=2) # along channels
    return BA # BA=(size, B_channel+A_channel)


# Save images to path: resize or merge
def save_images(images, path, size): # to size
    im = (images+1.0)*127.5 # restore to [0,255]
    im = rsz(im[0], size) # resize single image
    cv2.imwrite(path, im, [cv2.IMWRITE_PNG_COMPRESSION,3])

