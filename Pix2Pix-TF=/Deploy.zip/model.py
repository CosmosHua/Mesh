# coding:utf-8
#!/usr/bin/python3

import os, cv2
import numpy as np
import tensorflow as tf
from time import time
from ops import *


################################################################################
class pix2pix(object):
    def __init__(self, sess, args):
        """ Args:
            sess: TensorFlow session
            batch_size: The size of batch. Should be specified before training.
            input_size: The resolution in pixels of the input images. [256]
            output_size: The resolution in pixels of the output images. [256]
            gf_dim: (optional) Dimension of gen filters in first conv layer. [64]
            df_dim: (optional) Dimension of discrim filters in first conv layer. [64]
            input_nc: (optional) Dimension of input image color. For grayscale, set to 1. [3]
            output_nc: (optional) Dimension of output image color. For grayscale, set to 1. [3]
        """
        self.sess = sess
        self.args = args
        
        self.gf_dim = 64
        self.df_dim = 64
        self.input_size = 256
        self.output_size = 256

        self.input_nc = args.input_nc
        self.output_nc = args.output_nc
        #self.is_color = (args.input_nc==3)
        
        self.drop_kp = 1
        self.batch_size = 1
        self.isTrain = True
        self.build_model() # initialize model


    def build_model(self):
        shape = [self.batch_size, self.input_size, self.input_size, self.input_nc+self.output_nc]
        self.real_data = tf.placeholder(dtype=TType, shape=shape, name='real_A_and_B_images')
        
        self.real_A = self.real_data[:, :, :, self.input_nc:] # mesh image
        self.real_B = self.real_data[:, :, :, :self.input_nc] # clean image
        self.fake_B = self.generator(self.real_A) # recover image
        
        if self.input_size==250: # help(tf.pad): [batch_size,height,width,channels]
           paddings = tf.constant([[0, 0], [3, 3], [3, 3], [0, 0]])
           self.real_A = tf.pad(self.real_A, paddings=paddings, mode='REFLECT')
           self.real_B = tf.pad(self.real_B, paddings=paddings, mode='REFLECT')
        
        self.real_AB = tf.concat([self.real_A, self.real_B], 3)
        self.fake_AB = tf.concat([self.real_A, self.fake_B], 3)

        var_list = tf.trainable_variables()
        self.g_vars = [x for x in var_list if 'g_' in x.name] # generator
        self.d_vars = [x for x in var_list if 'd_' in x.name] # discriminator
        self.saver = tf.train.Saver()


    def generator(self, image):
        with tf.variable_scope("generator", reuse=tf.AUTO_REUSE) as scope:
            s = self.output_size; bn_train = self.isTrain
            s2, s4, s8, s16, s32, s64, s128 = [int(s/2**i) for i in range(1,8)]
            # scope.reuse_variables() # for sampler

            ReLU = lrelu # default=lrelu
            # image is (256 x 256 x input_nc)
            # e1 is (128 x 128 x self.gf_dim)
            e1 = conv2d(image, self.gf_dim, name='g_e1_conv')
            # e2 is (64 x 64 x self.gf_dim*2)
            e2 = batch_norm(conv2d(ReLU(e1), self.gf_dim*2, name='g_e2_conv'), bn_train, name="g_bn_e2")
            # e3 is (32 x 32 x self.gf_dim*4)
            e3 = batch_norm(conv2d(ReLU(e2), self.gf_dim*4, name='g_e3_conv'), bn_train, name="g_bn_e3")
            # e4 is (16 x 16 x self.gf_dim*8)
            e4 = batch_norm(conv2d(ReLU(e3), self.gf_dim*8, name='g_e4_conv'), bn_train, name="g_bn_e4")
            # e5 is (8 x 8 x self.gf_dim*8)
            e5 = batch_norm(conv2d(ReLU(e4), self.gf_dim*8, name='g_e5_conv'), bn_train, name="g_bn_e5")
            # e6 is (4 x 4 x self.gf_dim*8)
            e6 = batch_norm(conv2d(ReLU(e5), self.gf_dim*8, name='g_e6_conv'), bn_train, name="g_bn_e6")
            # e7 is (2 x 2 x self.gf_dim*8)
            e7 = batch_norm(conv2d(ReLU(e6), self.gf_dim*8, name='g_e7_conv'), bn_train, name="g_bn_e7")
            # e8 is (1 x 1 x self.gf_dim*8)
            e8 = batch_norm(conv2d(ReLU(e7), self.gf_dim*8, name='g_e8_conv'), bn_train, name="g_bn_e8")
            
            ReLU = Lrelu # default=tf.nn.relu
            # d1 is (2 x 2 x self.gf_dim*8*2)
            shape = [self.batch_size, s128, s128, self.gf_dim*8]
            d1, d1_w, d1_b = deconv2d(ReLU(e8), shape, name='g_d1')
            d1 = tf.nn.dropout(batch_norm(d1, bn_train, name="g_bn_d1"), self.drop_kp)
            d1 = tf.concat([d1, e7], 3)

            # d2 is (4 x 4 x self.gf_dim*8*2)
            shape = [self.batch_size, s64, s64, self.gf_dim*8]
            d2, d2_w, d2_b = deconv2d(ReLU(d1), shape, name='g_d2')
            d2 = tf.nn.dropout(batch_norm(d2, bn_train, name="g_bn_d2"), self.drop_kp)
            d2 = tf.concat([d2, e6], 3)

            # d3 is (8 x 8 x self.gf_dim*8*2)
            shape = [self.batch_size, s32, s32, self.gf_dim*8]
            d3, d3_w, d3_b = deconv2d(ReLU(d2), shape, name='g_d3')
            d3 = tf.nn.dropout(batch_norm(d3, bn_train, name="g_bn_d3"), self.drop_kp)
            d3 = tf.concat([d3, e5], 3)

            # d4 is (16 x 16 x self.gf_dim*8*2)
            shape = [self.batch_size, s16, s16, self.gf_dim*8]
            d4, d4_w, d4_b = deconv2d(ReLU(d3), shape, name='g_d4')
            d4 = tf.nn.dropout(batch_norm(d4, bn_train, name="g_bn_d4"), self.drop_kp)
            d4 = tf.concat([d4, e4], 3)

            # d5 is (32 x 32 x self.gf_dim*4*2)
            shape = [self.batch_size, s8, s8, self.gf_dim*4]
            d5, d5_w, d5_b = deconv2d(ReLU(d4), shape, name='g_d5')
            d5 = tf.concat([batch_norm(d5, bn_train, name="g_bn_d5"), e3], 3)

            # d6 is (64 x 64 x self.gf_dim*2*2)
            shape = [self.batch_size, s4, s4, self.gf_dim*2]
            d6, d6_w, d6_b = deconv2d(ReLU(d5), shape, name='g_d6')
            d6 = tf.concat([batch_norm(d6, bn_train, name="g_bn_d6"), e2], 3)

            # d7 is (128 x 128 x self.gf_dim*1*2)
            shape = [self.batch_size, s2, s2, self.gf_dim]
            d7, d7_w, d7_b = deconv2d(ReLU(d6), shape, name='g_d7')
            d7 = tf.concat([batch_norm(d7, bn_train, name="g_bn_d7"), e1], 3)

            # d8 is (256 x 256 x output_nc)
            shape = [self.batch_size, s, s, self.output_nc]
            d8, d8_w, d8_b = deconv2d(ReLU(d7), shape, name='g_d8')
            
            #print("\n" + "generator_"*6)
            #for i in (e1, e2, e3, e4, e5, e6, e7, e8): print(i)
            #for i in (d1, d2, d3, d4, d5, d6, d7, d8): print(i)
            return tf.nn.tanh(d8)


    def infer(self, args): # batch_size=1
        if os.path.isdir(args.test_dir):
            data = globs(args.test_dir, "*.jpg")
        else: data = [args.test_dir] # image path/np.array
        
        if not self.load_model(args.model_dir): return
        for i,image in enumerate(data): # batch_size=1
            im = self.load_data([image], isTrain=False); sz = (178,220)
            im = self.sess.run(self.fake_B, feed_dict={self.real_data: im})
            if type(image)==str: save_images(im, image[:-4]+"_.png", sz)
            else: im = rsz(127.5*(im[0]+1.0), sz); return im.astype("uint8")


    def load_model(self, model_dir):
        print(" [*] Loading checkpoint...")
        ckpt = tf.train.get_checkpoint_state(model_dir)
        if ckpt and ckpt.model_checkpoint_path:
            ckpt_name = os.path.basename(ckpt.model_checkpoint_path)
            model = os.path.join(model_dir, ckpt_name)
            self.saver.restore(self.sess, model)
            print(" [*] Load SUCCESS: %s" % model); return True
        else: print(" [!] Load FAIL!"); return False


    def load_data(self, data, isTrain):
        image = []
        for i,im in enumerate(data):
            img = load_image(im); image.append(img)
        return np.array(image).astype(np.float32)

